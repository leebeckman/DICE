File nomenclature is 

terms_<locale name>.txt

Where "<locale name>" should be any valid locale available
to the user in his profile page